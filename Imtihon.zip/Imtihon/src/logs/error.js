import { logger } from "../config/logger.js";

export const logError = (error) => {
  logger.error({
    message: error.message,
    time: new Date().toISOString()
  });
};
